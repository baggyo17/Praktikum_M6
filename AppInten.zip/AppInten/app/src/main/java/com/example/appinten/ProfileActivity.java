package com.example.appinten;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        final TextView hasil = (TextView) findViewById(R.id.hasildata);

        String data = getIntent().getExtras().getString("data");
        hasil.setText(data);

        Toast.makeText(this, "Data: " + data, Toast.LENGTH_SHORT).show();
    }
}
