package com.example.appinten;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void setButton1(View v) {
        Intent i = new Intent(MainActivity.this, ProfileActivity.class);
        i.putExtra("data", "NIM: 20210810058");
        startActivity(i);
    }

    public void setButton2(View v) {
        Intent i = new Intent(MainActivity.this, ProfileActivity.class);
        i.putExtra("data", "Nama: GILANG SUBAGIO");
        startActivity(i);
    }

    public void setButton3(View v) {
        Intent i = new Intent(MainActivity.this, ProfileActivity.class);
        i.putExtra("data", "Alamat: JLN. PRAMUKA GANG TUNAS 1 PURWAWINANGUN");
        startActivity(i);
    }

    public void setButton4(View v) {
        Intent i = new Intent(MainActivity.this, ProfileActivity.class);
        i.putExtra("data", "Tanggal Lahir: 24-06-2002");
        startActivity(i);
    }

    public void setButton5(View v) {
        Intent i = new Intent(MainActivity.this, ProfileActivity.class);
        i.putExtra("data", "Prodi: TEKNIK INFORMATIKA");
        startActivity(i);
    }
}
